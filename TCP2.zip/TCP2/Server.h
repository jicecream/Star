/*
 * Server.h
 *
 *  Created on: 8 Jan 2019
 *      Author: DELL
 */

#ifndef SERVER_H_
#define SERVER_H_

class Server {
public:
	Server();
	virtual ~Server();
};

#endif /* SERVER_H_ */
