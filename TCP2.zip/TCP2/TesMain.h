#ifndef TESMAIN_H
#define TESMAIN_H


class TesMain
{
    public:
        TesMain();
        virtual ~TesMain();

    protected:

    private:
};

#endif // TESMAIN_H
