g/*
 * Test.cpp
 *
 *  Created on: 3 Jan 2019
 *      Author: DELL
 */

#include "Test.h"


# include <winsock2.h>
#include<stdlib.h>
#include<stdio.h>
#include <sys/types.h>
#include <string.h>
#define PORT 8080

//#include <netinet/in.h>


 #pragma comment(lib,"ws2_32.lib") //Winsock Library

int main(int argc, char *argv[]){

	WSADATA wsa;
	int iWsaStartup;
	int iWsaCleanup;

	SOCKET TCPServerSocket;
	int iCloseSocket;

	//struct sockaddr_in TCPClientAdd;
	//int iTCPClientdd = sizeof(TCPClientAdd);



	int iSend;
	char SenderBuffer[512] = "Hello from Server";
	int iSenderBuffer = strlen(SenderBuffer) + 1;


	int sock_fd , newsock_fd, portno, valread;


	// specify address for the socket

		struct sockaddr_in server_address;
		int addrlen = sizeof(server_address);



	//int iListen;

	//	SOCKET sAcceptSocket;

//	int iRecv;
//  char RecvBuffer[512];
//	int iRecvBuffer = strlen(RecvBuffer)+1;



	printf("Hi there! How are you doing? \n");

sock_fd = socket(AF_INET, SOCK_STREAM, 0);

if(sock_fd ==0){

printf("socket failed");

}


server_address.sin_family = AF_INET;
 //port number
 server_address.sin_port= htons(PORT);
 //ip address
 server_address.sin_addr.s_addr = INADDR_ANY;
//call connect function


if(bind(sock_fd, (struct sockaddr *) &server_address, sizeof(server_address)  <0  )){
perror("ERROR on binding");
}


if (listen(sock_fd, 3) < 0)
    {
        perror("listen fail");

    }



//int new_socket= accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen);
int connectionStatus = connect(sock_fd, (struct sockaddr *) &server_address, sizeof(server_address));

if(connectionStatus == -1){

	perror("error connecting to remote socket \n");
}





 //server response

 //and close the socket



if(argc<2){
	perror("ERROR, no port provided ");
	//	printf("ERROR, no port provided \n");

	}



	//creating socket file descriptor
	if(sock_fd<=0) {
		perror("socket fail");
		exit(EXIT_FAILURE);

	}



	//forcefully attaching socket to port



	if(TCPServerSocket == INVALID_SOCKET){
		printf("Invalid Socket");

	}

	char server_response[256];
	recv(sock_fd, &server_response, sizeof(server_response), 0);

	printf("server sends the data: %s \n", server_response);




	close(sock_fd);

	   return 0;
}
