#ifndef HELLOWORLD_H
#define HELLOWORLD_H


class HelloWorld
{
    public:
        HelloWorld();
        virtual ~HelloWorld();

    protected:

    private:
};

#endif // HELLOWORLD_H
