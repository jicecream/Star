#include "HelloWorld.h"

HelloWorld::HelloWorld()
{
    //ctor
}

HelloWorld::~HelloWorld()
{
    //dtor
}
