
#include "Server.h"
# include <winsock2.h>
#include<stdlib.h>
#include<stdio.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h> // for open
#include <unistd.h> // for close
#define PORT 8080

int main(int argc, char *argv[]){


	//create the server socket
	char server_message[256] = "You have reached the server";
	int server_socket;
	server_socket = socket(AF_INET,SOCK_STREAM,0);

	//define the server address
	struct sockaddr_in server_address;

	if (listen(server_socket, 3) < 0)
    {
        perror("listen fail");

    }

    printf("Test");
	server_address.sin_family = AF_INET;
	server_address.sin_port = htons(9002);
	 server_address.sin_addr.s_addr = INADDR_ANY;
	//call connect function

	 //bind the socket to specified IP and port

	 bind(server_socket, (struct sockaddr*) &server_address, sizeof(server_address));
	 listen(server_socket, 5);

	 int client_socket;
	 client_socket = accept(server_socket, NULL, NULL);
	 //send message
	 send(client_socket, server_message, sizeof(server_message), 0);
//close socket

	 close(server_socket);




 	 return 0;


}
