/*
 ============================================================================
 Name        : HelloWorld3.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

# include <winsock2.h>
#include<stdlib.h>
#include<stdio.h>
#include <sys/types.h>
#include <string.h>
#include <WS2tcpip.h>

#define PORT 4455

int main(int argc, char *argv[]){
	printf("!!!Hello World!!!  \n"); /* prints !!!Hello World!!! */



	//create the server socket
	char server_message[1256];
	//old socket
	int serverSocket;
	//new socket
	int newSocket;

	//define the server address
	struct sockaddr_in serverAddress;
	struct sockaddr_in newAddress;
	socklen_t addrSize;


	serverSocket = socket(AF_INET,SOCK_STREAM,0);

	printf("created server socket \n");

	memset(&serverAddress, '\0', sizeof(serverAddress));

	serverAddress.sin_family = AF_INET;
	serverAddress.sin_port = htons(PORT);
	serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1");
	printf("port no: " + PORT);
	printf("defined server address \n");
	//bind serversocket with serveraddress
	bind(serverSocket, (struct sockaddr*) &serverAddress, sizeof(serverAddress));

	printf("bind server socket with sockaddr \n");

listen(serverSocket, 5);
addrSize = sizeof(newAddress);
newSocket = accept(serverSocket, (struct serverAddress*)&newAddress, &addrSize);

strcpy(buffer, "Hello");


if (listen(serverSocket, 5) < 0)
{
    perror("listen fail \n");

}
else{

	printf("listen \n");

}

//call connect function
newSocket= accept(serverSocket, (struct sockaddr*)&newAddress, &addrSize);








	return 0;
}
